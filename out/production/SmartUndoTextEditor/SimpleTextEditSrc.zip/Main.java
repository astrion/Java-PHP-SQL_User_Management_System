package TextEdit;

public class Main {
    public static void main(String[] args) {
        TextEdit runner = new TextEdit();
    }
}